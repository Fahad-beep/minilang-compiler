// minilang.cpp
// Single-file MiniLang: lexer, parser, AST, semantic checks, constant-folding, TAC, interpreter, CLI
// Compile: g++ -std=c++17 minilang.cpp -O2 -o minilang

#include <bits/stdc++.h>
using namespace std;

// Language specification embedded for documentation and classroom deliverable.
// Use the runtime flag `--spec` (or `-spec`) to print this specification.
static const char *MINILANG_SPEC = R"SPEC(
MiniLang (group project language)
=================================

Overview
--------
MiniLang is a tiny, integer-only imperative scripting language intended for
numerical pattern generation and simple control-flow exercises (loops, conditionals).
It is intentionally small so students can implement parsing, semantic checks,
optimization passes (constant folding), and a simple interpreter.

Lexical rules (tokens)
----------------------
- Integer literal: a non-empty sequence of digits, e.g. 0, 123
- Identifier: letter or underscore followed by letters, digits, or underscores: [A-Za-z_][A-Za-z0-9_]*
- Keywords: print, if, else, while
- Operators: + - * / % == != < > <= >= =
- Delimiters: ( ) { } ;
- Comment: line comment starting with // to end of line

BNF / EBNF Grammar (informal)
-----------------------------
program      := stmt_list
stmt_list    := { statement }
statement    := assignment ';'
                             | print_stmt ';'
                             | if_stmt
                             | while_stmt
                             | block
assignment   := IDENT '=' expr
print_stmt   := 'print' '(' expr ')'
if_stmt      := 'if' '(' expr ')' block [ 'else' block ]
while_stmt   := 'while' '(' expr ')' block
block        := '{' stmt_list '}'
expr         := equality
equality     := comparison { ( '==' | '!=' ) comparison }
comparison   := term { ('<' | '>' | '<=' | '>=') term }
term         := factor { ('+' | '-') factor }
factor       := unary { ('*' | '/' | '%') unary }
unary        := ('+' | '-') unary | primary
primary      := INT_LIT | IDENT | '(' expr ')'

Semantic rules and type system
------------------------------
- Single primitive type: integer (32/64-bit, represented here as signed 64-bit).
- Variables must be assigned before use (simple flow-insensitive checks performed per-block).
- Arithmetic operators operate on integers and yield integers. Division and modulo of zero are runtime errors.
- Comparison operators produce an integer value: 1 for true, 0 for false.
- There are no function definitions, no scoping beyond blocks, and no arrays or strings.

Static checks implemented in this runtime:
- Use-before-assign detection within blocks (basic conservative check).

Runtime semantics
-----------------
- Statements execute in order. An `if` evaluates the condition; non-zero is true.
- `while` loops evaluate condition before each iteration; non-zero is true.

Examples
--------
1) Fibonacci (iterative) — prints fib(10) -> 55
 a = 0;
 b = 1;
 i = 0;
 while (i < 10) {
     t = a + b;
     a = b;
     b = t;
     i = i + 1;
 }
 print(a);

2) Factorial (iterative) — prints 120 for n=5
 n = 5;
 res = 1;
 i = 1;
 while (i <= n) {
     res = res * i;
     i = i + 1;
 }
 print(res);

Notes / limitations
-------------------
- Only integer arithmetic and comparisons. Booleans are integers 0 or 1.
- No functions, no IO other than `print`.
- The language is intentionally minimal to serve as a teaching DSL.

)SPEC";

/* -----------------------
     Token / Lexer
     ----------------------- */
enum class TokenType {
        END,   // EOF
        INT_LIT, IDENT,
        PLUS, MINUS, MUL, DIV, MOD,
        ASSIGN, EQ, NEQ, LT, GT, LTE, GTE,
        LPAREN, RPAREN, LBRACE, RBRACE, SEMI,
        KW_PRINT, KW_IF, KW_ELSE, KW_WHILE,
};

string tokenTypeName(TokenType t) {
        switch(t){
                case TokenType::END: return "END";
                case TokenType::INT_LIT: return "INT";
                case TokenType::IDENT: return "IDENT";
                case TokenType::PLUS: return "+";
                case TokenType::MINUS: return "-";
                case TokenType::MUL: return "*";
                case TokenType::DIV: return "/";
                case TokenType::MOD: return "%";
                case TokenType::ASSIGN: return "=";
                case TokenType::EQ: return "==";
                case TokenType::NEQ: return "!=";
                case TokenType::LT: return "<";
                case TokenType::GT: return ">";
                case TokenType::LTE: return "<=";
                case TokenType::GTE: return ">=";
                case TokenType::LPAREN: return "(";
                case TokenType::RPAREN: return ")";
                case TokenType::LBRACE: return "{";
                case TokenType::RBRACE: return "}";
                case TokenType::SEMI: return ";";
                case TokenType::KW_PRINT: return "print";
                case TokenType::KW_IF: return "if";
                case TokenType::KW_ELSE: return "else";
                case TokenType::KW_WHILE: return "while";
        }
        return "TOK";
}

struct Token { TokenType type; string text; long long intVal; Token(TokenType t=TokenType::END, string s=""): type(t), text(s), intVal(0) {} };

struct Lexer {
    string src; size_t i=0; int line=1;
    Lexer(const string &s): src(s) { }
    char peek(){ return i < src.size() ? src[i] : '\0'; }
    char get(){ return i < src.size() ? src[i++] : '\0'; }
    bool startswith(const string &pat){ return src.substr(i, pat.size()) == pat; }
    Token nextToken(){
        while(true){
            char c = peek();
            if(c=='\0') return Token(TokenType::END, "");
            if(isspace(static_cast<unsigned char>(c))){ if(c=='\n') line++; get(); continue; }
            if(startswith("//")){ while(peek() && peek()!='\n') get(); continue; }
            if(isdigit(static_cast<unsigned char>(c))){ string s; while(isdigit(static_cast<unsigned char>(peek()))) s.push_back(get()); Token t(TokenType::INT_LIT, s); t.intVal = stoll(s); return t; }
            if(isalpha(static_cast<unsigned char>(c)) || c=='_'){ string s; while(isalnum(static_cast<unsigned char>(peek())) || peek()=='_') s.push_back(get()); if(s=="print") return Token(TokenType::KW_PRINT, s); if(s=="if") return Token(TokenType::KW_IF, s); if(s=="else") return Token(TokenType::KW_ELSE, s); if(s=="while") return Token(TokenType::KW_WHILE, s); return Token(TokenType::IDENT, s); }
            if(startswith("==")){ i+=2; return Token(TokenType::EQ, "=="); }
            if(startswith("!=")){ i+=2; return Token(TokenType::NEQ, "!="); }
            if(startswith("<=")){ i+=2; return Token(TokenType::LTE, "<="); }
            if(startswith(">=")){ i+=2; return Token(TokenType::GTE, ">="); }
            char ch = get();
            switch(ch){
                case '+': return Token(TokenType::PLUS, "+");
                case '-': return Token(TokenType::MINUS, "-");
                case '*': return Token(TokenType::MUL, "*");
                case '/': return Token(TokenType::DIV, "/");
                case '%': return Token(TokenType::MOD, "%");
                case '=': return Token(TokenType::ASSIGN, "=");
                case '<': return Token(TokenType::LT, "<");
                case '>': return Token(TokenType::GT, ">");
                case '(' : return Token(TokenType::LPAREN, "(");
                case ')' : return Token(TokenType::RPAREN, ")");
                case '{' : return Token(TokenType::LBRACE, "{");
                case '}' : return Token(TokenType::RBRACE, "}");
                case ';' : return Token(TokenType::SEMI, ";");
                default: cerr<<"Lexer error: unexpected char '"<<ch<<"'\n"; exit(1);
            }
        }
    }
};

struct NodeBase { virtual ~NodeBase(){} };
struct Expr : NodeBase { virtual long long eval(map<string,long long>&env) = 0; };
struct Stmt : NodeBase { virtual void exec(map<string,long long>&env) = 0; };

struct IntLit : Expr { long long v; IntLit(long long vv): v(vv){} long long eval(map<string,long long>&) override { return v; } };
struct VarExpr : Expr { string name; VarExpr(const string &n): name(n){} long long eval(map<string,long long>&env) override { if(env.find(name)==env.end()){ cerr<<"Runtime error: use of undefined variable '"<<name<<"'\n"; exit(1);} return env[name]; } };
struct Binary : Expr { string op; unique_ptr<Expr> a,b; Binary(const string &op_, unique_ptr<Expr> a_, unique_ptr<Expr> b_): op(op_), a(move(a_)), b(move(b_)){} long long eval(map<string,long long>&env) override { long long A=a->eval(env), B=b->eval(env); if(op=="+") return A+B; if(op=="-") return A-B; if(op=="*") return A*B; if(op=="/"){ if(B==0){ cerr<<"Runtime error: division by zero\n"; exit(1);} return A/B; } if(op=="%") return A%B; if(op=="==") return A==B; if(op=="!=") return A!=B; if(op=="<") return A<B; if(op==">") return A>B; if(op=="<=") return A<=B; if(op==">=") return A>=B; cerr<<"Runtime error: unknown op "<<op<<"\n"; exit(1); } };

struct PrintStmt : Stmt { unique_ptr<Expr> e; PrintStmt(unique_ptr<Expr> e_): e(move(e_)){} void exec(map<string,long long>&env) override { cout<<e->eval(env)<<"\n"; } };
struct AssignStmt : Stmt { string name; unique_ptr<Expr> e; AssignStmt(const string &n, unique_ptr<Expr> e_): name(n), e(move(e_)){} void exec(map<string,long long>&env) override { long long val = e->eval(env); env[name]=val; } };
struct BlockStmt : Stmt { vector<unique_ptr<Stmt>> stmts; void exec(map<string,long long>&env) override { for(auto &s: stmts) s->exec(env); } };
struct IfStmt : Stmt { unique_ptr<Expr> cond; unique_ptr<BlockStmt> thenBlock; unique_ptr<BlockStmt> elseBlock; IfStmt(unique_ptr<Expr> c, unique_ptr<BlockStmt> t, unique_ptr<BlockStmt> e): cond(move(c)), thenBlock(move(t)), elseBlock(move(e)){} void exec(map<string,long long>&env) override { if(cond->eval(env)) thenBlock->exec(env); else if(elseBlock) elseBlock->exec(env); } };
struct WhileStmt : Stmt { unique_ptr<Expr> cond; unique_ptr<BlockStmt> body; WhileStmt(unique_ptr<Expr> c, unique_ptr<BlockStmt> b): cond(move(c)), body(move(b)){} void exec(map<string,long long>&env) override { while(cond->eval(env)) body->exec(env); } };

// Note: use different class names than earlier to avoid confusion in this compact file
struct Parser {
    Lexer lex; Token cur; Parser(const string &s): lex(s) { cur = lex.nextToken(); }
    void eat(TokenType t){ if(cur.type==t) cur = lex.nextToken(); else { cerr<<"Parse error: expected "<<tokenTypeName(t)<<" but got "<<tokenTypeName(cur.type)<<" ('"<<cur.text<<"')\n"; exit(1); } }
    unique_ptr<BlockStmt> parseProgram(){ auto root = make_unique<BlockStmt>(); while(cur.type!=TokenType::END) root->stmts.push_back(parseStatement()); return root; }
    unique_ptr<Stmt> parseStatement(){
        if(cur.type==TokenType::KW_PRINT){ eat(TokenType::KW_PRINT); eat(TokenType::LPAREN); auto e=parseExpr(); eat(TokenType::RPAREN); eat(TokenType::SEMI); return make_unique<PrintStmt>(move(e)); }
        if(cur.type==TokenType::IDENT){ string name=cur.text; eat(TokenType::IDENT); eat(TokenType::ASSIGN); auto e=parseExpr(); eat(TokenType::SEMI); return make_unique<AssignStmt>(name, move(e)); }
        if(cur.type==TokenType::KW_IF){ eat(TokenType::KW_IF); eat(TokenType::LPAREN); auto cond=parseExpr(); eat(TokenType::RPAREN); auto thenB=parseBlock(); unique_ptr<BlockStmt> elseB=nullptr; if(cur.type==TokenType::KW_ELSE){ eat(TokenType::KW_ELSE); elseB=parseBlock(); } return make_unique<IfStmt>(move(cond), move(thenB), move(elseB)); }
        if(cur.type==TokenType::KW_WHILE){ eat(TokenType::KW_WHILE); eat(TokenType::LPAREN); auto cond=parseExpr(); eat(TokenType::RPAREN); auto body=parseBlock(); return make_unique<WhileStmt>(move(cond), move(body)); }
        if(cur.type==TokenType::LBRACE) return parseBlock();
        cerr<<"Parse error: unexpected token "<<tokenTypeName(cur.type)<<" ('"<<cur.text<<"')\n"; exit(1);
    }
    unique_ptr<BlockStmt> parseBlock(){ eat(TokenType::LBRACE); auto blk=make_unique<BlockStmt>(); while(cur.type!=TokenType::RBRACE) blk->stmts.push_back(parseStatement()); eat(TokenType::RBRACE); return blk; }
    unique_ptr<Expr> parseExpr(){ return parseEquality(); }
    unique_ptr<Expr> parseEquality(){ auto left=parseComparison(); while(cur.type==TokenType::EQ||cur.type==TokenType::NEQ){ string op=cur.text; eat(cur.type); auto right=parseComparison(); left=make_unique<Binary>(op, move(left), move(right)); } return left; }
    unique_ptr<Expr> parseComparison(){ auto left=parseTerm(); while(cur.type==TokenType::LT||cur.type==TokenType::GT||cur.type==TokenType::LTE||cur.type==TokenType::GTE){ string op=cur.text; eat(cur.type); auto right=parseTerm(); left=make_unique<Binary>(op, move(left), move(right)); } return left; }
    unique_ptr<Expr> parseTerm(){ auto left=parseFactor(); while(cur.type==TokenType::PLUS||cur.type==TokenType::MINUS){ string op=cur.text; eat(cur.type); auto right=parseFactor(); left=make_unique<Binary>(op, move(left), move(right)); } return left; }
    unique_ptr<Expr> parseFactor(){ auto left=parseUnary(); while(cur.type==TokenType::MUL||cur.type==TokenType::DIV||cur.type==TokenType::MOD){ string op=cur.text; eat(cur.type); auto right=parseUnary(); left=make_unique<Binary>(op, move(left), move(right)); } return left; }
    unique_ptr<Expr> parseUnary(){ if(cur.type==TokenType::PLUS){ eat(TokenType::PLUS); return parseUnary(); } else if(cur.type==TokenType::MINUS){ eat(TokenType::MINUS); auto r=parseUnary(); return make_unique<Binary>(string("-"), make_unique<IntLit>(0), move(r)); } else return parsePrimary(); }
    unique_ptr<Expr> parsePrimary(){ if(cur.type==TokenType::INT_LIT){ long long v=cur.intVal; eat(TokenType::INT_LIT); return make_unique<IntLit>(v); } else if(cur.type==TokenType::IDENT){ string name=cur.text; eat(TokenType::IDENT); return make_unique<VarExpr>(name); } else if(cur.type==TokenType::LPAREN){ eat(TokenType::LPAREN); auto e=parseExpr(); eat(TokenType::RPAREN); return e; } cerr<<"Parse error: unexpected primary"<<"\n"; exit(1); }
};

/* Semantic check */
void semanticCheckBlock(BlockStmt* blk, set<string>& defined){
    for(auto &s: blk->stmts){
        if(auto as = dynamic_cast<AssignStmt*>(s.get())){
            function<void(Expr*)> findVars = [&](Expr* e){ if(!e) return; if(auto ve = dynamic_cast<VarExpr*>(e)){ if(defined.find(ve->name)==defined.end()){ cerr<<"Semantic error: variable '"<<ve->name<<"' used before assignment\n"; exit(1);} } else if(auto b = dynamic_cast<Binary*>(e)){ findVars(b->a.get()); findVars(b->b.get()); } };
            findVars(as->e.get()); defined.insert(as->name);
        } else if(auto ifs = dynamic_cast<IfStmt*>(s.get())){
            function<void(Expr*)> findVars = [&](Expr* e){ if(!e) return; if(auto ve = dynamic_cast<VarExpr*>(e)){ if(defined.find(ve->name)==defined.end()){ cerr<<"Semantic error: variable '"<<ve->name<<"' used before assignment\n"; exit(1);} } else if(auto b = dynamic_cast<Binary*>(e)){ findVars(b->a.get()); findVars(b->b.get()); } };
            findVars(ifs->cond.get());
            // check then and else with copies of defined
            set<string> thenDef = defined; semanticCheckBlock(ifs->thenBlock.get(), thenDef);
            if(ifs->elseBlock){ set<string> elseDef = defined; semanticCheckBlock(ifs->elseBlock.get(), elseDef); }
        } else if(auto wh = dynamic_cast<WhileStmt*>(s.get())){
            function<void(Expr*)> findVars = [&](Expr* e){ if(!e) return; if(auto ve = dynamic_cast<VarExpr*>(e)){ if(defined.find(ve->name)==defined.end()){ cerr<<"Semantic error: variable '"<<ve->name<<"' used before assignment\n"; exit(1);} } else if(auto b = dynamic_cast<Binary*>(e)){ findVars(b->a.get()); findVars(b->b.get()); } };
            findVars(wh->cond.get());
            set<string> bodyDef = defined; semanticCheckBlock(wh->body.get(), bodyDef);
        } else if(auto blk2 = dynamic_cast<BlockStmt*>(s.get())){
            semanticCheckBlock(blk2, defined);
        } else if(dynamic_cast<PrintStmt*>(s.get())){
            auto ps = static_cast<PrintStmt*>(s.get()); function<void(Expr*)> findVars = [&](Expr* e){ if(!e) return; if(auto ve = dynamic_cast<VarExpr*>(e)){ if(defined.find(ve->name)==defined.end()){ cerr<<"Semantic error: variable '"<<ve->name<<"' used before assignment\n"; exit(1);} } else if(auto b = dynamic_cast<Binary*>(e)){ findVars(b->a.get()); findVars(b->b.get()); } }; findVars(ps->e.get());
        }
    }
}

// Constant folding
unique_ptr<Expr> foldExpr(unique_ptr<Expr> e){
    if(auto b = dynamic_cast<Binary*>(e.get())){
        b->a = foldExpr(move(b->a));
        b->b = foldExpr(move(b->b));
        if(auto A = dynamic_cast<IntLit*>(b->a.get())){
            if(auto B = dynamic_cast<IntLit*>(b->b.get())){
                long long av = A->v, bv = B->v; long long r=0; bool ok=true;
                if(b->op=="+") r = av + bv; else if(b->op=="-") r = av - bv; else if(b->op=="*") r = av * bv; else if(b->op=="/"){ if(bv==0) ok=false; else r = av / bv; } else if(b->op=="%") { if(bv==0) ok=false; else r = av % bv; } else if(b->op=="==") r = av==bv; else if(b->op=="!=") r = av!=bv; else if(b->op=="<") r = av < bv; else if(b->op==">") r = av > bv; else if(b->op=="<=") r = av <= bv; else if(b->op==">=") r = av >= bv; else ok=false;
                if(ok) return make_unique<IntLit>(r);
            }
        }
        return e;
    }
    return e;
}

void foldConstantsInBlock(BlockStmt* blk){
    for(auto &s : blk->stmts){
        if(auto as = dynamic_cast<AssignStmt*>(s.get())){ as->e = foldExpr(move(as->e)); }
        else if(auto ifs = dynamic_cast<IfStmt*>(s.get())){ ifs->cond = foldExpr(move(ifs->cond)); foldConstantsInBlock(ifs->thenBlock.get()); if(ifs->elseBlock) foldConstantsInBlock(ifs->elseBlock.get()); }
        else if(auto wh = dynamic_cast<WhileStmt*>(s.get())){ wh->cond = foldExpr(move(wh->cond)); foldConstantsInBlock(wh->body.get()); }
        else if(auto blk2 = dynamic_cast<BlockStmt*>(s.get())) foldConstantsInBlock(blk2);
        else if(auto ps = dynamic_cast<PrintStmt*>(s.get())) ps->e = foldExpr(move(ps->e));
    }
}

// Simple TAC generator (textual)
struct TACGen {
    vector<string> code; int tmpCounter = 0;
    string newTmp(){ return string("t") + to_string(++tmpCounter); }
    string genExpr(Expr* e){
        if(auto il = dynamic_cast<IntLit*>(e)){
            return to_string(il->v);
        } else if(auto ve = dynamic_cast<VarExpr*>(e)){
            return ve->name;
        } else if(auto b = dynamic_cast<Binary*>(e)){
            string A = genExpr(b->a.get()); string B = genExpr(b->b.get()); string t = newTmp(); code.push_back(t + " = " + A + " " + b->op + " " + B); return t;
        }
        cerr<<"TAC gen: unhandled expr\n"; exit(1);
    }
    void genStmt(Stmt* s){
        if(auto as = dynamic_cast<AssignStmt*>(s)){
            string r = genExpr(as->e.get()); code.push_back(as->name + " = " + r);
        } else if(auto ps = dynamic_cast<PrintStmt*>(s)){
            string r = genExpr(ps->e.get()); code.push_back(string("print ") + r);
        } else if(auto ifs = dynamic_cast<IfStmt*>(s)){
            string c = genExpr(ifs->cond.get()); string L1 = string("L") + to_string(code.size()) + "a"; string L2 = string("L") + to_string(code.size()) + "b";
            code.push_back(string("ifz ") + c + " goto " + L1);
            genBlock(ifs->thenBlock.get()); code.push_back(string("goto ") + L2);
            code.push_back(L1 + ":");
            if(ifs->elseBlock) genBlock(ifs->elseBlock.get());
            code.push_back(L2 + ":");
        } else if(auto wh = dynamic_cast<WhileStmt*>(s)){
            string L1 = string("L") + to_string(code.size()) + "a"; string L2 = string("L") + to_string(code.size()) + "b";
            code.push_back(L1 + ":"); string c = genExpr(wh->cond.get()); code.push_back(string("ifz ") + c + " goto " + L2); genBlock(wh->body.get()); code.push_back(string("goto ") + L1); code.push_back(L2 + ":");
        } else if(auto blk = dynamic_cast<BlockStmt*>(s)){
            genBlock(blk);
        } else {
            cerr<<"TAC gen: unknown stmt\n"; exit(1);
        }
    }
    void genBlock(BlockStmt* blk){ for(auto &s : blk->stmts) genStmt(s.get()); }
};

void runSource(const string &source, bool verbose=false){
    Parser p(source);
    auto prog = p.parseProgram();
    set<string> defined;
    semanticCheckBlock(prog.get(), defined);
    foldConstantsInBlock(prog.get());
    TACGen gen; gen.genBlock(prog.get());
    if(verbose){ cout<<"--- TAC ---\n"; for(auto &l: gen.code) cout<<l<<"\n"; cout<<"--- END TAC ---\n"; }
    map<string,long long> env;
    prog->exec(env);
}

string loadFile(const string &path){ ifstream in(path); if(!in) { cerr<<"Cannot open file: "<<path<<"\n"; exit(1);} string s((istreambuf_iterator<char>(in)), istreambuf_iterator<char>()); return s; }

int main(int argc, char **argv){
    string defaultProg = R"MINI(
// compute fibonacci iteratively and print fib(10)
 a = 0;
 b = 1;
 i = 0;
 while (i < 10) {
   t = a + b;
   a = b;
   b = t;
   i = i + 1;
 }
 print(a);
)MINI";

    // runtime flags: --spec prints the language specification, -v enables TAC verbose
    if(argc >= 2){ string arg0 = argv[1]; if(arg0=="--spec" || arg0=="-spec"){ cout<<MINILANG_SPEC<<"\n"; return 0; } }

    string source;
    bool verbose = false;
    if(argc >= 2){ string arg = argv[1]; if(arg=="-v") { verbose=true; if(argc>=3) source = loadFile(argv[2]); else source = defaultProg; } else { source = loadFile(arg); } }
    else source = defaultProg;

    runSource(source, verbose);
    return 0;
}